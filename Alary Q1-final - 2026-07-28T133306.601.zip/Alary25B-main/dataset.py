from datasets import load_dataset, interleave_datasets, get_dataset_config_names
from huggingface_hub import HfApi
from tokenizers import Tokenizer
import torch

# Not: DEFAULT_MAX_LENGTH model config'indeki max_position_embeddings ile
# eşleştirilmeli. 25B model 128000 context için tasarlandı.
DEFAULT_MAX_LENGTH = 128000
PAD_ID = 0

tokenizer = Tokenizer.from_file("tokenizer.json")
tokenizer.enable_padding(pad_id=PAD_ID, pad_token="<pad>")
tokenizer.enable_truncation(max_length=DEFAULT_MAX_LENGTH)

def tokenize_function(examples):
    encoded = tokenizer.encode_batch(examples["text"])
    return {"input_ids": [e.ids for e in encoded], "attention_mask": [e.attention_mask for e in encoded]}

# ---------------------------------------------------------------------------
# KENDİ VERİ SETİMİZ (FineWeb2 DEĞİL) — Gokturk97/AlaryQ1CodeQdata
# Yapı: data/{dil_kodu}/*.parquet (clean_raw_commoncrawl_streaming.py'nin
# ürettiği repo). FineWeb2'nin aksine bu repo'yu HF config listesinden değil,
# kendi dosya ağacımızdan (data/<dil>/) keşfediyoruz — discover_data_dirs
# starcoderdata/stack-v2 için zaten aynı mantığı kullanıyordu, burada da
# tekrar kullanıyoruz.
# ---------------------------------------------------------------------------
OWN_DATASET_REPO = "Gokturk97/AlaryQ1CodeQdata"

# starcoderdata / the-stack-v2 / kendi reponuz hepsi data_dir bazlı; klasör
# isimlerini elle yazmak yerine HF Hub'dan otomatik keşfediyoruz.
_NON_DATA_ENTRIES = {
    ".gitattributes", "README.md", ".gitignore", "LICENSE", "dataset_infos.json",
}

def discover_data_dirs(repo_id):
    api = HfApi()
    files = api.list_repo_files(repo_id=repo_id, repo_type="dataset")
    dirs = set()
    for f in files:
        if "/" in f:
            top = f.split("/", 1)[0]
            if top not in _NON_DATA_ENTRIES and not top.startswith("."):
                dirs.add(top)
    return sorted(dirs)

def get_code_dataset_all_dirs(repo_id, hf_split="train"):
    data_dirs = discover_data_dirs(repo_id)
    if not data_dirs:
        raise RuntimeError(
            f"{repo_id} için hiçbir data_dir bulunamadı — erişim izni "
            f"(gated dataset onayı / huggingface-cli login) eksik olabilir."
        )
    lang_datasets = [
        load_dataset(repo_id, data_dir=d, streaming=True, split=hf_split, trust_remote_code=True)
        for d in data_dirs
    ]
    return interleave_datasets(lang_datasets, stopping_strategy="all_exhausted")

def get_own_dataset_all_languages(hf_split="train"):
    """
    Kendi reponuzdaki 'data/{dil}/' altındaki TÜM dilleri (600B hedefli:
    100B EN + 200B TR + 300B diğer 300 dil) keşfedip birlikte karıştırır.
    discover_data_dirs, repo yapımıza (data/<lang>/*.parquet) zaten uygun,
    starcoderdata ile aynı mekanizmayı burada tekrar kullanıyoruz.
    """
    return get_code_dataset_all_dirs(OWN_DATASET_REPO, hf_split=hf_split)

# ---------------------------------------------------------------------------
# MATH VERİSİ — Nemotron-CC-Math-v1 (nvidia)
# 133B token'lık en yüksek kaliteli açık math pretraining korpusu (Common
# Crawl'dan, LaTeX/denklem koruyucu). "3" + "4plus" config'leri birlikte
# "3plus" (133B) alt kümesini oluşturuyor. Biz sadece "4plus" (en yüksek
# kalite, ~52B) + "3" (orta-yüksek kalite, ~81B) karışımından hedefimiz olan
# ~100B'ye yakın bir miktar kullanıyoruz.
# NOT: Bu dataset "gated" (kullanım şartlarını HF'de kabul etmen gerekiyor,
# NVIDIA Data Agreement) — ilk kullanımdan önce
# https://huggingface.co/datasets/nvidia/Nemotron-CC-Math-v1 sayfasında
# "Agree" demen ve `huggingface-cli login` ile giriş yapmış olman lazım.
# ---------------------------------------------------------------------------
MATH_DATASET_REPO = "nvidia/Nemotron-CC-Math-v1"
MATH_TARGET_TOKENS = 100_000_000_000  # ~100B token hedefi

def get_math_dataset(hf_split="train"):
    high_quality = load_dataset(MATH_DATASET_REPO, "4plus", streaming=True, split=hf_split)
    mid_quality = load_dataset(MATH_DATASET_REPO, "3", streaming=True, split=hf_split)
    # 4plus (en yüksek kalite) öncelikli ağırlıklandırılıyor, 3 ile tamamlanıyor.
    return interleave_datasets(
        [high_quality, mid_quality],
        probabilities=[0.55, 0.45],
        stopping_strategy="all_exhausted",
    )

# Not: Kendi reponuz, starcoderdata, the-stack-v2 ve math dataset'i hiçbiri
# gerçek bir "validation" split'i sunmuyor (yalnızca "train" var).
# Bunun yerine train akışının başından küçük bir dilimi ayırıp
# (VALIDATION_SIZE kadar örnek) sözde-validation olarak kullanıyoruz.
VALIDATION_SIZE = 10_000

def get_dataset(split="train", num_shards=1, shard_index=0):
    """
    num_shards / shard_index: TPU (veya çoklu-cihaz) eğitiminde her çekirdeğin
    akışın FARKLI bir diliminden okuması için kullanılır.

    Karışım (üç ana kaynak):
      - Kendi veri setimiz (Gokturk97/AlaryQ1CodeQdata): ~600B hedef
      - Kod (starcoderdata + the-stack-v2, DOĞAL oranında, TAMAMI): ~1.15T
      - Math (Nemotron-CC-Math): ~100B hedef

      UYARI: Bu üç kaynağın toplamı (~600B + ~1.15T + ~100B ≈ 1.85T) hâlâ
      train.py'deki TARGET_TOKENS (4T) hedefinin ALTINDA. all_exhausted
      stratejisiyle küçük kaynaklar (kendi veri setimiz + math) büyük kaynak
      (stack-v2) bitene kadar TEKRAR TEKRAR döngüye girecek (epoch tekrarı).
      Bu, "temiz/tekrarsız 4T" değil, "~1.85T benzersiz + tekrarla 4T'ye
      tamamlama" anlamına gelir. TARGET_TOKENS'ı 4T'den ~1.85T'ye düşürmek
      ya da epoch tekrarını bilinçli kabul etmek gerekiyor — train.py'yi
      buna göre güncellemek ister misin?
    """
    code_ds_list = [
        get_code_dataset_all_dirs("bigcode/starcoderdata", hf_split="train"),
        get_code_dataset_all_dirs("bigcode/the-stack-v2", hf_split="train"),
    ]
    code_combined = interleave_datasets(
        code_ds_list,
        probabilities=[0.22, 0.78],  # ~250B / ~900B doğal oranı
        stopping_strategy="all_exhausted",
    )

    own_stream = get_own_dataset_all_languages(hf_split="train")
    math_stream = get_math_dataset(hf_split="train")

    # Kendi veri setimiz : kod : math ≈ 600B : 1150B : 100B → ~33% : ~62% : ~5%
    combined = interleave_datasets(
        [own_stream, code_combined, math_stream],
        probabilities=[0.33, 0.62, 0.05],
        stopping_strategy="all_exhausted",
    )

    if split == "validation":
        combined = combined.take(VALIDATION_SIZE)
    else:
        combined = combined.skip(VALIDATION_SIZE)

    from datasets.distributed import split_dataset_by_node
    if num_shards > 1:
        combined = split_dataset_by_node(combined, rank=shard_index, world_size=num_shards)

    return combined.map(tokenize_function, batched=True)

def collate_fn(batch):
    input_ids = torch.tensor([item["input_ids"] for item in batch])
    attention_mask = torch.tensor([item["attention_mask"] for item in batch])

    # Pad token'ları (id=0) loss hesaplamasından hariç tutmak için -100 ile maskele.
    # Aksi halde model padding'i de tahmin etmeye çalışır ve loss anlamsızlaşır.
    labels = input_ids.clone()
    labels[labels == PAD_ID] = -100

    return {
        "input_ids": input_ids,
        "attention_mask": attention_mask,
        "labels": labels,
    }
