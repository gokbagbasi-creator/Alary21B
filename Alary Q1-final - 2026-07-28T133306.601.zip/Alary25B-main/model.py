from transformers import LlamaConfig, LlamaForCausalLM


def build_config(attn_implementation="flash_attention_2"):
    """Alary25B mimarisi. train.py bu fonksiyonu import edip aynı config'i
    kullanır; attn_implementation GPU/TPU'ya göre train.py tarafından
    seçilip buraya parametre olarak geçiliyor (çift tanım olmasın diye)."""
    return LlamaConfig(
        hidden_size=5120,
        intermediate_size=20480,
        num_hidden_layers=64,
        num_attention_heads=32,
        num_key_value_heads=8,
        vocab_size=128000,
        max_position_embeddings=128000,
        attention_bias=False,
        bos_token_id=1,
        eos_token_id=2,
        rope_theta=2_000_000.0,
        # GPU'da (H100/H200, Ampere+) Flash Attention 2 kullan — TPU'da bu
        # kwarg yok sayılır/hata verir, TPU'ya dönersen "sdpa" yap.
        # Gerekli paket: pip install flash-attn --no-build-isolation
        attn_implementation=attn_implementation,
    )


# Bu blok SADECE `python model.py` ile doğrudan çalıştırılınca devreye
# girer; train.py `from model import build_config` yaptığında model
# yeniden inşa edilip diske yazılmaz — sadece config fonksiyonu kullanılır.
if __name__ == "__main__":
    _attn_impl = "flash_attention_2" if torch.cuda.is_available() else "sdpa"
    config = build_config(attn_implementation=_attn_impl)
    model = LlamaForCausalLM(config)

    # Model parametrelerini kontrol et
    total_params = model.num_parameters()
    print(f"Model parametreleri: {total_params:,} ({total_params/1e9:.1f}B)")
    print(f"Config kaydediliyor...")

    model.save_pretrained("Alary25B")
    config.save_pretrained("Alary25B")

    print("✅ Alary25B modeli başarıyla kaydedildi!")
