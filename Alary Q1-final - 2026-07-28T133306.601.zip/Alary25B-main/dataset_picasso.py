import webdataset as wds
from tokenizers import Tokenizer
from torchvision import transforms
import torch
from functools import partial

TAR_PATTERN = "laion_shards/{00000..NNNNN}.tar"  # kendi shard path'ine göre değiştir
MAX_CAPTION_LENGTH = 77
PAD_ID = 0

tokenizer = Tokenizer.from_file("caption_tokenizer.json")
tokenizer.enable_padding(pad_id=PAD_ID, pad_token="<pad>", length=MAX_CAPTION_LENGTH)
tokenizer.enable_truncation(max_length=MAX_CAPTION_LENGTH)

preprocess = transforms.Compose([
    transforms.Resize(128, interpolation=transforms.InterpolationMode.BICUBIC),
    transforms.CenterCrop(128),
    transforms.ToTensor(),
    transforms.Normalize([0.5], [0.5]),  # VAE [-1, 1] aralığı bekliyor
])

def tokenize_caption(caption):
    encoded = tokenizer.encode(caption.strip())
    return torch.tensor(encoded.ids), torch.tensor(encoded.attention_mask)

def make_dataset(num_shards=1, shard_index=0):
    """
    num_shards / shard_index: TPU'nun (veya çoklu-GPU'nun) her çekirdeğine
    shard'ların FARKLI bir alt kümesini vermek için. Bunu ayarlamazsan
    (varsayılan num_shards=1) her çekirdek aynı shard'ları baştan okur —
    hem gereksiz indirme/ağ yükü hem de etkisiz veri kullanımı.
    """
    nodesplitter = partial(wds.split_by_node, rank=shard_index, world_size=num_shards) if num_shards > 1 else wds.single_node_only
    return (
        wds.WebDataset(TAR_PATTERN, shardshuffle=True, nodesplitter=nodesplitter)
        .decode("pil")
        .to_tuple("jpg;png", "txt")
        .map_tuple(preprocess, tokenize_caption)
    )

def collate_fn(batch):
    images = torch.stack([b[0] for b in batch])
    input_ids = torch.stack([b[1][0] for b in batch])
    attention_mask = torch.stack([b[1][1] for b in batch])
    return {
        "pixel_values": images,
        "input_ids": input_ids,
        "attention_mask": attention_mask,
    }
