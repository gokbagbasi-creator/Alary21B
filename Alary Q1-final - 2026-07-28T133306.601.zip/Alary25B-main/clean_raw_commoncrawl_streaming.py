"""
Alary Q1 CodeQ - GERÇEK Common Crawl Streaming Temizleme Pipeline'ı
=====================================================================
Bu versiyon FineWeb2 gibi ÖNCEDEN İŞLENMİŞ bir kaynak KULLANMAZ.
Doğrudan Common Crawl'ın kendi WET dosyalarını (ham metin çıkarımı yapılmış
WARC türevleri) HTTPS üzerinden STREAM eder - hiçbir dosya diske inmez.

Neden WET (WARC değil)?
    WARC ham HTML içerir, HTML->metin çıkarımı (Trafilatura vb.) gerektirir,
    bu çok daha ağır bir CPU işlemi. WET dosyaları Common Crawl tarafından
    ÖNCEDEN metne çevrilmiş halidir (boilerplate/etiket temizliği CC'nin kendi
    extraction'ı ile yapılmış) - bizim işimiz sadece DİL FİLTRELEME + KALİTE
    FİLTRELEME + DEDUP olduğu için WET yeterli ve çok daha hızlı.
    (İstersen WARC+Trafilatura moduna da geçebilirsin, aşağıda not var.)

Neden 200B Türkçe FineWeb2'den çıkmıyor?
    FineWeb2 zaten kendi filtrelerini uygulamış, dil-başına hacmi CC'nin
    HAM halinden çok daha düşük. Ham CC'yi baştan taramak, Türkçe gibi
    web'de göreceli az olan dillerde çok daha fazla kaynak doküman sağlar
    (küçük bir yüzdesi hedef dilde olsa bile, taranan toplam hacim devasa
    olduğu için mutlak sayı çok daha yüksek çıkar).

Mimari:
    - TEK GEÇİŞ, ÇOK DİL: Aynı CC dump'ı 302 kere ayrı ayrı taramak yerine,
      dosyaları BİR KEZ okuyup her dokümanı dil tespitiyle DOĞRU dil kovasına
      yönlendiriyoruz. Aksi halde aynı veriyi yüzlerce kez indirmiş olurduk.
    - Her CPU worker'ı kendi WET dosyasını stream eder, bellekte filtreler,
      küçük shard'lar halinde HF Hub'a yükler, geçici dosyayı siler.
    - Dil bazlı token bütçeleri paylaşımlı bir sayaç (multiprocessing.Manager)
      ile takip edilir; bir dilin bütçesi dolunca o dildeki dokümanlar atlanır.

Kurulum:
    pip install requests warcio fasttext-wheel huggingface_hub pandas pyarrow datasketch

    # fastText dil tespit modelini indir (bir kereye mahsus):
    wget https://dl.fbaipublicfiles.com/fasttext/supervised-models/lid.176.bin

Çalıştırma:
    export HF_TOKEN=hf_xxxxxxxx
    python3 clean_raw_commoncrawl_streaming.py --snapshot CC-MAIN-2025-30 --max-files 20000
"""

import os
import re
import io
import gzip
import json
import time
import logging
import tempfile
import argparse
import multiprocessing as mp
from typing import Dict, List, Optional

import requests
from warcio.archiveiterator import ArchiveIterator
import fasttext
import pandas as pd
from huggingface_hub import HfApi, create_repo
from datasketch import MinHash, MinHashLSH

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(message)s")
logger = logging.getLogger("alary-cc-raw-stream")

# ---------------------------------------------------------------------------
# AYARLAR
# ---------------------------------------------------------------------------
HF_REPO_ID = "Gokturk97/AlaryQ1CodeQdata"
HF_TOKEN = os.environ.get("HF_TOKEN")
UPLOAD_FORMAT = "parquet"
SHARD_DOC_COUNT = 20_000
TEMP_DIR = tempfile.gettempdir()

CC_DATA_BASE = "https://data.commoncrawl.org/"
LID_MODEL_PATH = os.environ.get("FASTTEXT_LID_PATH", "lid.176.bin")

# --- Sıkı kalite eşikleri ---
LANG_CONFIDENCE_THRESHOLD = 0.85
MIN_DOC_WORDS = 100
MAX_SYMBOL_TO_WORD_RATIO = 0.08
MAX_REPEATED_NGRAM_RATIO = 0.12
MIN_AVG_WORD_LENGTH = 3.0
MAX_UPPERCASE_RATIO = 0.25
NEAR_DEDUP_JACCARD_THRESHOLD = 0.75

# ---------------------------------------------------------------------------
# DİL BÜTÇESİ
# ---------------------------------------------------------------------------
TIER_1_LANGS = {
    "fr": 20.0, "de": 15.0, "es": 15.0, "pt": 10.0, "it": 10.0,
    "ru": 12.0, "zh": 15.0, "ar": 10.0, "ja": 10.0, "nl": 8.0,
    "pl": 6.0, "id": 6.0, "vi": 6.0, "ko": 8.0, "fa": 4.0,
}
TIER_2_LANGS = [
    "uk", "el", "sv", "cs", "ro", "hu", "fi", "da", "no", "bg",
    "hr", "sk", "sr", "lt", "sl", "lv", "et", "he", "th", "hi",
    "bn", "ur", "ta", "te", "ml", "kn", "mr", "gu", "pa", "ms",
]
EN_BUDGET, TR_BUDGET, OTHERS_TARGET = 100.0, 200.0, 300.0


def build_language_budgets(other_lang_codes: List[str]) -> Dict[str, float]:
    budgets = {"en": EN_BUDGET, "tr": TR_BUDGET}
    budgets.update(TIER_1_LANGS)
    for lang in TIER_2_LANGS:
        budgets[lang] = 2.5
    remaining = [l for l in other_lang_codes if l not in budgets and l not in TIER_2_LANGS]
    tier1_2_total = sum(TIER_1_LANGS.values()) + len(TIER_2_LANGS) * 2.5
    remaining_target = OTHERS_TARGET - tier1_2_total
    if remaining:
        per_lang = max(remaining_target / len(remaining), 0.01)
        for lang in remaining:
            budgets[lang] = round(per_lang, 4)
    logger.info(f"Toplam planlanan bütçe: {sum(budgets.values()):.1f}B token (hedef: 600B)")
    return budgets


# ---------------------------------------------------------------------------
# KALİTE FİLTRELERİ
# ---------------------------------------------------------------------------
_WORD_RE = re.compile(r"\w+", re.UNICODE)
_SYMBOL_RE = re.compile(r"[^\w\s]", re.UNICODE)


def passes_strict_quality(text: str) -> bool:
    if not text or len(text.strip()) < 200:
        return False
    words = _WORD_RE.findall(text)
    n_words = len(words)
    if n_words < MIN_DOC_WORDS:
        return False
    avg_word_len = sum(len(w) for w in words) / max(n_words, 1)
    if avg_word_len < MIN_AVG_WORD_LENGTH:
        return False
    symbols = _SYMBOL_RE.findall(text)
    if len(symbols) / max(n_words, 1) > MAX_SYMBOL_TO_WORD_RATIO:
        return False
    upper_chars = sum(1 for c in text if c.isupper())
    alpha_chars = sum(1 for c in text if c.isalpha())
    if alpha_chars > 0 and (upper_chars / alpha_chars) > MAX_UPPERCASE_RATIO:
        return False
    trigrams = [tuple(words[i:i + 3]) for i in range(max(len(words) - 2, 0))]
    if trigrams:
        unique_ratio = len(set(trigrams)) / len(trigrams)
        if (1 - unique_ratio) > MAX_REPEATED_NGRAM_RATIO:
            return False
    if not re.search(r"[.!?…]\s*$", text.strip()):
        return False
    return True


def get_shingles(text: str, k: int = 5) -> List[str]:
    words = _WORD_RE.findall(text.lower())
    return [" ".join(words[i:i + k]) for i in range(max(len(words) - k + 1, 0))]


class WindowedNearDedup:
    """Bellekte sınırlı, periyodik sıfırlanan yaklaşık dedup (worker başına ayrı)."""

    def __init__(self, threshold: float = NEAR_DEDUP_JACCARD_THRESHOLD, reset_every: int = 100_000):
        self.threshold = threshold
        self.reset_every = reset_every
        self._count = 0
        self._new_lsh()

    def _new_lsh(self):
        self.lsh = MinHashLSH(threshold=self.threshold, num_perm=64)

    def is_duplicate(self, text: str, doc_id: str) -> bool:
        self._count += 1
        if self._count % self.reset_every == 0:
            self._new_lsh()
        mh = MinHash(num_perm=64)
        for sh in get_shingles(text):
            mh.update(sh.encode("utf-8"))
        if self.lsh.query(mh):
            return True
        self.lsh.insert(f"{doc_id}_{self._count}", mh)
        return False


def approx_token_count(text: str) -> int:
    return int(len(_WORD_RE.findall(text)) * 1.3)


# ---------------------------------------------------------------------------
# CC DUMP DOSYA LİSTESİNİ ÇEK (WET path listesi)
# ---------------------------------------------------------------------------

def fetch_wet_paths(snapshot: str, max_files: Optional[int] = None) -> List[str]:
    """
    Common Crawl'ın resmi wet.paths.gz index dosyasını indirir (bu KÜÇÜK bir
    dosyadır, ~1-5 MB - asıl veri değil, sadece dosya YOLLARI listesi).
    """
    index_url = f"{CC_DATA_BASE}crawl-data/{snapshot}/wet.paths.gz"
    logger.info(f"WET dosya listesi indiriliyor: {index_url}")
    resp = requests.get(index_url, stream=True, timeout=60)
    resp.raise_for_status()
    raw = gzip.decompress(resp.content)
    paths = raw.decode("utf-8").strip().split("\n")
    if max_files:
        paths = paths[:max_files]
    logger.info(f"{len(paths)} WET dosyası işlenecek (snapshot: {snapshot})")
    return paths


# ---------------------------------------------------------------------------
# TEK BİR WET DOSYASINI STREAM ET (diske hiç yazmadan)
# ---------------------------------------------------------------------------

def stream_wet_records(wet_path: str):
    """
    Bir WET dosyasını HTTPS üzerinden stream eder, warcio ile parse eder.
    `requests` stream=True kullanıldığı için dosyanın tamamı belleğe/diske
    inmez - parça parça (chunk) okunup işlenir.
    """
    url = CC_DATA_BASE + wet_path
    with requests.get(url, stream=True, timeout=120) as resp:
        resp.raise_for_status()
        # warcio, gzip'li stream'i doğrudan okuyabilir (raw response stream'i verir)
        stream = io.BufferedReader(resp.raw, buffer_size=1024 * 1024)
        for record in ArchiveIterator(stream):
            if record.rec_type != "conversion":
                continue  # WET dosyalarında asıl metin "conversion" tipi kayıtlarda
            content = record.content_stream().read()
            try:
                text = content.decode("utf-8", errors="ignore")
            except Exception:
                continue
            uri = record.rec_headers.get_header("WARC-Target-URI") or ""
            yield uri, text


# ---------------------------------------------------------------------------
# WORKER: bir grup WET dosyasını işler, dil kovalarına dağıtır, HF'ye yükler
# ---------------------------------------------------------------------------

def upload_shard_and_delete(docs: List[dict], lang_code: str, shard_idx: int, worker_id: int):
    if not HF_TOKEN or not docs:
        return
    api = HfApi(token=HF_TOKEN)
    ext = "parquet" if UPLOAD_FORMAT == "parquet" else "txt"
    fname = f"{lang_code}_w{worker_id}_shard{shard_idx:05d}.{ext}"
    local_path = os.path.join(TEMP_DIR, fname)
    try:
        if UPLOAD_FORMAT == "parquet":
            pd.DataFrame(docs).to_parquet(local_path, engine="pyarrow", index=False)
        else:
            with open(local_path, "w", encoding="utf-8") as f:
                for d in docs:
                    f.write(d["text"] + "\n\n")
        repo_path = f"data/{lang_code}/{fname}"
        api.upload_file(path_or_fileobj=local_path, path_in_repo=repo_path,
                         repo_id=HF_REPO_ID, repo_type="dataset")
        logger.info(f"[worker {worker_id}][{lang_code}] shard {shard_idx} yüklendi ({len(docs)} doküman)")
    finally:
        if os.path.exists(local_path):
            os.remove(local_path)


def process_wet_file_list(worker_id: int, wet_paths: List[str], budgets: Dict[str, float],
                           shared_counters: dict, counter_lock, lid_model_path: str):
    lid_model = fasttext.load_model(lid_model_path)
    dedup_by_lang: Dict[str, WindowedNearDedup] = {}
    buffers: Dict[str, List[dict]] = {}
    shard_idx_by_lang: Dict[str, int] = {}

    for wet_path in wet_paths:
        # Tüm dillerin bütçesi dolduysa bu worker'ın işi biter
        with counter_lock:
            all_done = all(shared_counters.get(l, 0) >= budgets[l] * 1e9 for l in budgets)
        if all_done:
            logger.info(f"[worker {worker_id}] tüm dil bütçeleri doldu, duruyor.")
            break

        try:
            for uri, text in stream_wet_records(wet_path):
                if len(text.strip()) < 200:
                    continue

                pred = lid_model.predict(text[:2000].replace("\n", " "), k=1)
                lang_label = pred[0][0].replace("__label__", "")
                confidence = pred[1][0]

                if lang_label not in budgets or confidence < LANG_CONFIDENCE_THRESHOLD:
                    continue

                with counter_lock:
                    if shared_counters.get(lang_label, 0) >= budgets[lang_label] * 1e9:
                        continue  # bu dilin bütçesi zaten dolu

                if not passes_strict_quality(text):
                    continue

                dedup = dedup_by_lang.setdefault(lang_label, WindowedNearDedup())
                if dedup.is_duplicate(text, uri):
                    continue

                tok_count = approx_token_count(text)
                buffers.setdefault(lang_label, []).append(
                    {"text": text, "id": uri, "lang": lang_label, "token_count": tok_count}
                )

                with counter_lock:
                    shared_counters[lang_label] = shared_counters.get(lang_label, 0) + tok_count

                if len(buffers[lang_label]) >= SHARD_DOC_COUNT:
                    idx = shard_idx_by_lang.get(lang_label, 0)
                    upload_shard_and_delete(buffers[lang_label], lang_label, idx, worker_id)
                    shard_idx_by_lang[lang_label] = idx + 1
                    buffers[lang_label] = []

        except Exception as e:
            logger.warning(f"[worker {worker_id}] {wet_path} işlenirken hata: {e}, sonraki dosyaya geçiliyor.")
            continue

    # kalan tüm buffer'ları yükle
    for lang_label, docs in buffers.items():
        if docs:
            idx = shard_idx_by_lang.get(lang_label, 0)
            upload_shard_and_delete(docs, lang_label, idx, worker_id)

    logger.info(f"[worker {worker_id}] tamamlandı.")


# ---------------------------------------------------------------------------
# ANA ÇALIŞTIRMA
# ---------------------------------------------------------------------------

def ensure_hf_repo_exists():
    if not HF_TOKEN:
        logger.warning("HF_TOKEN yok, repo oluşturma atlanıyor.")
        return
    create_repo(repo_id=HF_REPO_ID, repo_type="dataset", token=HF_TOKEN, exist_ok=True, private=False)
    logger.info(f"HF dataset reposu hazır: https://huggingface.co/datasets/{HF_REPO_ID}")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--snapshot", default="CC-MAIN-2025-30", help="Common Crawl snapshot adı")
    parser.add_argument("--max-files", type=int, default=None, help="Test için WET dosya sayısını sınırla")
    parser.add_argument("--n-workers", type=int, default=mp.cpu_count())
    args = parser.parse_args()

    if not os.path.exists(LID_MODEL_PATH):
        raise FileNotFoundError(
            f"fastText dil tespit modeli bulunamadı: {LID_MODEL_PATH}\n"
            "İndir: wget https://dl.fbaipublicfiles.com/fasttext/supervised-models/lid.176.bin"
        )

    ensure_hf_repo_exists()

    OTHER_LANG_CODES_PLACEHOLDER = [f"lang_{i}" for i in range(257)]  # gerçek listeyle değiştir
    budgets = build_language_budgets(OTHER_LANG_CODES_PLACEHOLDER)

    wet_paths = fetch_wet_paths(args.snapshot, max_files=args.max_files)

    # WET dosyalarını worker'lar arasında böl (round-robin)
    n_workers = args.n_workers
    chunks: List[List[str]] = [[] for _ in range(n_workers)]
    for i, p in enumerate(wet_paths):
        chunks[i % n_workers].append(p)

    manager = mp.Manager()
    shared_counters = manager.dict({lang: 0 for lang in budgets})
    counter_lock = manager.Lock()

    logger.info(f"{n_workers} paralel worker ile {len(wet_paths)} WET dosyası (TEK GEÇİŞ, tüm diller) işlenecek.")

    procs = []
    for wid in range(n_workers):
        p = mp.Process(
            target=process_wet_file_list,
            args=(wid, chunks[wid], budgets, shared_counters, counter_lock, LID_MODEL_PATH),
        )
        p.start()
        procs.append(p)

    for p in procs:
        p.join()

    logger.info("Tüm worker'lar tamamlandı.")
    for lang, count in shared_counters.items():
        logger.info(f"  {lang}: {count/1e9:.2f}B / {budgets[lang]:.2f}B token")
    logger.info(f"Dataset: https://huggingface.co/datasets/{HF_REPO_ID}")
