from datasets import load_dataset, interleave_datasets
from huggingface_hub import HfApi
from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.trainers import BpeTrainer

# Not: Bu dosya dataset.py'yi import ETMEZ çünkü dataset.py modül yüklenirken
# "tokenizer.json" dosyasını okumaya çalışıyor (Tokenizer.from_file) — ama bu
# script'in görevi tam olarak o dosyayı YARATMAK. Bu yüzden aynı dil/klasör
# keşif mantığı burada bağımsız olarak tekrarlanıyor (döngüsel import'u önlemek için).

tokenizer = Tokenizer(BPE())

trainer = BpeTrainer(
    vocab_size=128000,
    special_tokens=[
        "<pad>",
        "<bos>",
        "<eos>",
        "<unk>"
    ]
)

# Not: FineWeb-2 yerine artık KENDİ reponuz (Gokturk97/AlaryQ1CodeQdata)
# kullanılıyor — dataset.py'deki gerçek pretraining karışımıyla tutarlı
# olması için. Ayrıca math verisi (Nemotron-CC-Math, LaTeX/denklem ağırlıklı)
# eklendi; bu olmadan tokenizer LaTeX sembollerini yeterince görmez ve
# math içeriğini verimsiz (gereksiz parçalanmış) tokenize eder.
def discover_own_dataset_configs():
    return discover_data_dirs("Gokturk97/AlaryQ1CodeQdata")

# starcoderdata / the-stack-v2 de data_dir bazlı; klasör isimlerini elle
# yazmak yerine HF Hub'dan otomatik keşfediyoruz.
_NON_DATA_ENTRIES = {
    ".gitattributes", "README.md", ".gitignore", "LICENSE", "dataset_infos.json",
}

def discover_data_dirs(repo_id):
    api = HfApi()
    files = api.list_repo_files(repo_id=repo_id, repo_type="dataset")
    dirs = set()
    for f in files:
        if "/" in f:
            top = f.split("/", 1)[0]
            if top not in _NON_DATA_ENTRIES and not top.startswith("."):
                dirs.add(top)
    return sorted(dirs)

print("Kendi veri setiniz açılıyor (Gokturk97/AlaryQ1CodeQdata)...")
own_dirs = discover_own_dataset_configs()
own_datasets = [
    load_dataset("Gokturk97/AlaryQ1CodeQdata", data_dir=d, streaming=True, split="train", trust_remote_code=True)
    for d in own_dirs
]
own_all = interleave_datasets(own_datasets, stopping_strategy="all_exhausted")

print("starcoderdata klasörleri keşfediliyor...")
starcoder_dirs = discover_data_dirs("bigcode/starcoderdata")
starcoder_datasets = [
    load_dataset("bigcode/starcoderdata", data_dir=d, streaming=True, split="train", trust_remote_code=True)
    for d in starcoder_dirs
]
starcoder_all = interleave_datasets(starcoder_datasets, stopping_strategy="all_exhausted")

print("the-stack-v2 klasörleri keşfediliyor...")
stackv2_dirs = discover_data_dirs("bigcode/the-stack-v2")
stackv2_datasets = [
    load_dataset("bigcode/the-stack-v2", data_dir=d, streaming=True, split="train", trust_remote_code=True)
    for d in stackv2_dirs
]
stackv2_all = interleave_datasets(stackv2_datasets, stopping_strategy="all_exhausted")

print("Math verisi açılıyor (Nemotron-CC-Math)...")
math_high = load_dataset("nvidia/Nemotron-CC-Math-v1", "4plus", streaming=True, split="train")
math_mid = load_dataset("nvidia/Nemotron-CC-Math-v1", "3", streaming=True, split="train")
math_all = interleave_datasets([math_high, math_mid], probabilities=[0.55, 0.45], stopping_strategy="all_exhausted")

ds_list = [own_all, starcoder_all, stackv2_all, math_all]

# Kendi veri seti : starcoderdata : stack-v2 : math ≈ 600B : 250B : 900B : 100B
# doğal oranlarına yakın bir ağırlıklandırma (dataset.py'deki gerçek
# pretraining karışımıyla tutarlı olsun diye).
dataset = interleave_datasets(ds_list, probabilities=[0.33, 0.13, 0.49, 0.05], stopping_strategy="all_exhausted")


def batch_iterator(batch_size=1000):
    """Veri setinden text çıkarmak için iterator."""
    batch = []
    for example in dataset:
        # Farklı veri setlerinde 'text' field'i farklı isimlerde olabilir
        text = None
        if "text" in example:
            text = example["text"]
        elif "content" in example:
            text = example["content"]
        elif "code" in example:
            text = example["code"]

        if text and isinstance(text, str):
            batch.append(text)

            if len(batch) == batch_size:
                yield batch
                batch = []

    # Kalan batch'i gönder
    if batch:
        yield batch


print("Tokenizer eğitiliyor...")
tokenizer.train_from_iterator(
    batch_iterator(),
    trainer=trainer
)

print("✅ Tokenizer eğitimi tamamlandı!")
tokenizer.save("tokenizer.json")
print("✅ Tokenizer kaydedildi!")
