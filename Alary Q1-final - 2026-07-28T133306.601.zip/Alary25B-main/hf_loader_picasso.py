from huggingface_hub import HfApi, create_repo

REPO_ID = "Gokturk97/Alary_Picasso_mini"
LOCAL_DIR = "Alary_Picasso_mini_Final"  # train_picasso.py'nin ürettiği klasör:
                                         #   dit/ (PixArtTransformer2DModel, save_pretrained)
                                         #   text_encoder.pt (CaptionTextEncoder state_dict)
                                         #   caption_tokenizer.json

def push_to_hub():
    api = HfApi()
    create_repo(REPO_ID, exist_ok=True)

    api.upload_folder(
        folder_path=LOCAL_DIR,
        repo_id=REPO_ID,
        repo_type="model",
    )

    print(f"✅ Model şuraya yüklendi: https://huggingface.co/{REPO_ID}")

if __name__ == "__main__":
    push_to_hub()
