import torch
import torch.nn as nn

# Not: vocab_size, tokenizer_trainer_picasso.py'deki VOCAB_SIZE ile birebir
# eşleşmeli (orada 32000). Bu encoder CLIP'in aksine DONDURULMUYOR — DiT ile
# birlikte sıfırdan eğitiliyor, çünkü kendi tokenizer'ımızın ürettiği
# token id'lerini anlayan hazır/pretrained bir model yok.

VOCAB_SIZE = 32000
HIDDEN_SIZE = 512          # PixArt config'indeki cross_attention_dim/caption_channels ile eşleşmeli
NUM_LAYERS = 4
NUM_HEADS = 8
MLP_RATIO = 4
MAX_CAPTION_LENGTH = 77
PAD_ID = 0

class CaptionTextEncoder(nn.Module):
    def __init__(
        self,
        vocab_size=VOCAB_SIZE,
        hidden_size=HIDDEN_SIZE,
        num_layers=NUM_LAYERS,
        num_heads=NUM_HEADS,
        mlp_ratio=MLP_RATIO,
        max_length=MAX_CAPTION_LENGTH,
        pad_id=PAD_ID,
    ):
        super().__init__()
        self.pad_id = pad_id

        self.token_embedding = nn.Embedding(vocab_size, hidden_size, padding_idx=pad_id)
        self.position_embedding = nn.Embedding(max_length, hidden_size)

        encoder_layer = nn.TransformerEncoderLayer(
            d_model=hidden_size,
            nhead=num_heads,
            dim_feedforward=hidden_size * mlp_ratio,
            activation="gelu",
            batch_first=True,
            norm_first=True,  # pre-LN: derin transformer'larda daha stabil eğitim
        )
        self.encoder = nn.TransformerEncoder(encoder_layer, num_layers=num_layers)
        self.final_norm = nn.LayerNorm(hidden_size)

    def forward(self, input_ids, attention_mask=None):
        # input_ids: (batch, seq_len), attention_mask: (batch, seq_len) — 1=gerçek token, 0=pad
        batch_size, seq_len = input_ids.shape
        positions = torch.arange(seq_len, device=input_ids.device).unsqueeze(0).expand(batch_size, -1)

        hidden_states = self.token_embedding(input_ids) + self.position_embedding(positions)

        # nn.TransformerEncoder'ın src_key_padding_mask'i "True = görmezden gel" bekliyor,
        # bizim attention_mask'imizde ise "1 = gerçek token" — bu yüzden tersine çeviriyoruz.
        padding_mask = None
        if attention_mask is not None:
            padding_mask = attention_mask == 0

        hidden_states = self.encoder(hidden_states, src_key_padding_mask=padding_mask)
        return self.final_norm(hidden_states)  # (batch, seq_len, hidden_size) -> encoder_hidden_states


if __name__ == "__main__":
    model = CaptionTextEncoder()
    total_params = sum(p.numel() for p in model.parameters())
    print(f"CaptionTextEncoder parametreleri: {total_params:,} ({total_params/1e6:.1f}M)")
