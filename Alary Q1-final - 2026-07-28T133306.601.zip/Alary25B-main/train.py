import os
import shutil
import torch
from huggingface_hub import HfApi
from accelerate import Accelerator
from accelerate.utils import set_seed
from transformers import LlamaForCausalLM, LlamaConfig, Adafactor
from torch.utils.data import DataLoader
from dataset import get_dataset, collate_fn
from model import build_config  # Alary25B config artık tek yerde (model.py) tanımlı

# ============================================================================
# TPU + FSDP KURULUM NOTU (GPU için aşağıda kısa not var)
# ============================================================================
# GPU (ör. TRUBA kolyoz-cuda, 4x H100/node) KULLANACAKSAN:
#   accelerate config
#   -> "Which type of machine are you using?"  => multi-GPU (veya tek node
#      birden fazla GPU varsa "multi-GPU", FSDP soruluyorsa YES/FULL_SHARD)
#   Kodun geri kalanı DEĞİŞMİYOR — accelerate + FSDP soyutlaması TPU/GPU
#   arasında aynı kalıyor, sadece `accelerate config` cevapların değişiyor.
# ============================================================================
# 25B parametreli bu model bf16'da tek başına ~50GB tutuyor — TEK bir TPU
# çekirdeğinin HBM'ine (v3: 16GB, v4: 32GB) sığmaz. Bu yüzden düz "veri
# paralelliği" (her çekirdekte modelin tam kopyası) YETERSİZ kalır ve OOM
# verir. Modeli çekirdekler arasında PARÇALAMAK (FSDP) şart.
#
# Kurulum:
#   accelerate config
#   -> "Which type of machine are you using?"           => TPU
#   -> "How many TPU cores should be used?"              => TPU'nun çekirdek sayısı (ör. 8)
#   -> FSDP / sharding ile ilgili soru çıkarsa            => EVET / FULL_SHARD
#      (Bu sorunun tam ifadesi accelerate sürümüne göre değişebilir; TPU
#       seçildikten sonra "fully sharded" / "XLA FSDP" ile ilgili bir soru
#       göreceksin, onu onaylaman gerekiyor. Yoksa `accelerate launch` düz
#       veri paralelliğine düşer ve model sığmaz.)
#   -> Diğer sorularda güvenli varsayılanları kullanabilirsin (dynamo: NO)
#
# Ardından:
#   accelerate launch train.py
#
# FSDP KOD KURALI: Optimizer, model FSDP ile SARILDIKTAN (accelerator.prepare
# edildikten) SONRA, o parçalanmış modelin parametreleriyle oluşturulmalı.
# Aksi halde parametre grupları eğitim sırasında eşleşmez ve hata alırsın.
# Bu yüzden aşağıda prepare(model) ve optimizer oluşturma sırası bilerek
# ayrıldı — tek seferde prepare(model, optimizer, ...) YAPILMIYOR.
# ============================================================================

set_seed(42)
accelerator = Accelerator(mixed_precision="bf16", gradient_accumulation_steps=8)
# ---------------------------------------------------------------------------
# DİSKSİZ ORTAM İÇİN: checkpoint'leri diske değil, RAM-tabanlı tmpfs'e
# (/dev/shm) yaz. accelerator.save_state() bir dosya yoluna yazmak ZORUNDA
# (tamamen dosyasız/bellek-içi yazmak mümkün değil) ama /dev/shm bir dosya
# yolu gibi görünse de gerçekte RAM'de duruyor, kalıcı diske hiç dokunmuyor.
#
# ÖNEMLİ SINIR: /dev/shm varsayılan olarak host RAM'inin yarısı kadar
# boyuta sahiptir. 25B model checkpoint'i (ağırlık+optimizer state) bf16'da
# ~100-150GB civarı olabilir — TPU VM'in host RAM'i bunun altındaysa
# (ör. 128GB RAM'de /dev/shm sadece 64GB), checkpoint SIĞMAZ ve save_state
# "No space left on device" hatası verir. VM'inin RAM boyutunu önceden
# kontrol et (`free -h`), gerekirse tmpfs boyutunu büyütmen gerekebilir:
#   sudo mount -o remount,size=100G /dev/shm
output_dir = "/dev/shm/alary_checkpoints"
os.makedirs(output_dir, exist_ok=True)

# ---------------------------------------------------------------------------
# ÜCRETSİZ/SINIRLI DİSK İÇİN: checkpoint rotasyonu + HF Hub'a yedekleme
# ---------------------------------------------------------------------------
# Ücretsiz disk kotası sınırlı olduğu için TÜM checkpoint'leri yerelde
# biriktirmiyoruz. Her yeni checkpoint kaydedilince:
#   1. Önce checkpoint HF Hub'a yüklenir (Gokturk97/AlaryQ1CodeQdata reposu,
#      "checkpoints/checkpoint-{step}/" altına) -> kalıcı, disk-bağımsız yedek
#   2. Yükleme başarılı olduktan SONRA, sadece son KEEP_LOCAL_CHECKPOINTS
#      kadarı diskte tutulur, daha eskiler silinir.
# Böylece disk asla birkaç checkpoint'ten fazla büyümez, ama hiçbir
# checkpoint kaybolmaz (hepsi HF'de duruyor).
CHECKPOINT_HF_REPO = "Gokturk97/AlaryQ1CodeQdata"
KEEP_LOCAL_CHECKPOINTS = 2
_hf_api = HfApi()


def upload_checkpoint_to_hub(ckpt_path: str, step: int):
    """Bir checkpoint klasörünü HF Hub'a yükler. Hata olursa eğitimi
    DURDURMAZ (yedekleme aksasa bile eğitim devam etsin), sadece uyarı basar."""
    if not os.environ.get("HF_TOKEN"):
        print("⚠️  HF_TOKEN yok, checkpoint HF'ye yüklenemiyor (sadece yerelde kalacak).")
        return False
    try:
        _hf_api.upload_folder(
            folder_path=ckpt_path,
            path_in_repo=f"checkpoints/checkpoint-{step}",
            repo_id=CHECKPOINT_HF_REPO,
            repo_type="dataset",
        )
        print(f"☁️  checkpoint-{step} HF Hub'a yüklendi -> {CHECKPOINT_HF_REPO}:checkpoints/checkpoint-{step}")
        return True
    except Exception as e:
        print(f"⚠️  checkpoint-{step} HF'ye yüklenemedi ({e}), yerelde tutuluyor (silinmeyecek).")
        return False


def rotate_local_checkpoints(output_dir: str, keep: int = KEEP_LOCAL_CHECKPOINTS):
    """Sadece en yeni `keep` kadar checkpoint'i diskte bırakır, gerisini siler.
    (upload_checkpoint_to_hub başarılı olduysa çağrılmalı — aksi halde
    HF'ye hiç yüklenmemiş bir checkpoint'i silmiş oluruz.)"""
    ckpts = sorted(
        [d for d in os.listdir(output_dir) if d.startswith("checkpoint-")],
        key=lambda d: int(d.split("-")[1]),
    )
    for old_ckpt in ckpts[:-keep] if keep > 0 else ckpts:
        old_path = os.path.join(output_dir, old_ckpt)
        shutil.rmtree(old_path, ignore_errors=True)
        print(f"🗑️  disk doldurmasın diye silindi: {old_path} (HF Hub'da yedeği duruyor)")


def save_checkpoint_with_rotation(accelerator, output_dir: str, step: int):
    ckpt_path = os.path.join(output_dir, f"checkpoint-{step}")
    accelerator.save_state(ckpt_path)
    if accelerator.is_main_process:
        uploaded = upload_checkpoint_to_hub(ckpt_path, step)
        if uploaded:
            rotate_local_checkpoints(output_dir)
        else:
            print(f"ℹ️  Yükleme başarısız olduğu için checkpoint-{step} silinmedi, disk kotasını takip et.")

# Hedef: ~1.85T token (kendi veri setimiz ~600B + kod ~1.15T + math ~100B).
# Not: dataset.py'deki üç kaynağın (own + code + math) TOPLAM benzersiz
# hacmi bu kadar; all_exhausted stratejisiyle küçük kaynaklar büyük kaynak
# (stack-v2) bitene kadar bir miktar tekrar edebilir ama bu artık ~2.2x'lik
# büyük bir epoch tekrarı DEĞİL, sadece kaynaklar arası doğal dengeleme.
TARGET_TOKENS = 1_850_000_000_000
tokens_seen = 0

# Model yükle
# GPU'da (H100/H200) Flash Attention 2 kullan; TPU'ya dönersen "sdpa" yap.
_attn_impl = "flash_attention_2" if torch.cuda.is_available() else "sdpa"

try:
    model = LlamaForCausalLM.from_pretrained("Alary25B", attn_implementation=_attn_impl)
    print("📦 Var olan Alary25B checkpoint'i yüklendi.")
except OSError:
    print("Alary25B bulunamadı, model.py'deki config ile sıfırdan oluşturuluyor...")
    config = build_config(attn_implementation=_attn_impl)
    model = LlamaForCausalLM(config)
    model.save_pretrained("Alary25B")
    config.save_pretrained("Alary25B")
    total_params = model.num_parameters()
    print(f"✅ Alary25B oluşturuldu ve kaydedildi: {total_params:,} ({total_params/1e9:.1f}B)")

# gradient_checkpointing açıkken use_cache=True kalırsa (bazı transformers
# sürümlerinde) çelişki/uyarı oluşur ve gereksiz KV-cache belleği harcanır;
# eğitimde zaten cache kullanılmaz, açıkça kapatıyoruz.
model.config.use_cache = False
model.gradient_checkpointing_enable()

# ---------------------------------------------------------------------------
# FP8 (torchao) — H100/H200 (Hopper, compute capability 9.0) ve Ada (8.9)
# GPU'larda çalışır; TPU'da/eski GPU'larda hiçbir şey yapmadan atlar.
# Mimariyi DEĞİŞTİRMEZ: nn.Linear katmanlarını yerinde FP8'e "sarar", geri
# kalan kod (forward/backward/FSDP) aynı kalır. FSDP'den ÖNCE uygulanmalı.
# Gerekli paket: pip install torchao
# ---------------------------------------------------------------------------
if torch.cuda.is_available() and torch.cuda.get_device_capability() >= (8, 9):
    try:
        from torchao.float8 import convert_to_float8_training, Float8LinearConfig
        convert_to_float8_training(model, config=Float8LinearConfig())
        print("⚡ FP8 (torchao) etkinleştirildi.")
    except ImportError:
        print("⚠️  torchao bulunamadı (pip install torchao), FP8 atlanıyor, bf16 ile devam ediliyor.")
else:
    print("ℹ️  FP8 için Hopper/Ada (compute capability ≥ 8.9-9.0) GPU gerekli, bf16 ile devam ediliyor.")

# --- ÖNCE modeli prepare et (FSDP burada devreye girip modeli parçalar) ---
model = accelerator.prepare(model)

# --- SONRA optimizer'ı, parçalanmış modelin parametreleriyle oluştur ---
optimizer = Adafactor(model.parameters(), lr=1e-4, relative_step=False, scale_parameter=False)

# NOT: streaming (IterableDataset) + çoklu worker process TPU/XLA'da
# güvenilir çalışmayabilir, bu yüzden num_workers=0 kalıyor (GPU'da da
# streaming dataset ile num_workers>0 kullanmak istersen dikkatli test et).
# pin_memory sadece CUDA'da anlamlı, GPU'daysak açıyoruz (host->device
# kopyasını hızlandırır), TPU'da otomatik kapalı kalır.
#
# num_shards/shard_index: accelerator.num_processes / accelerator.process_index
# her cihaza (GPU veya TPU çekirdeği) akışın FARKLI bir dilimini veriyor.
# Bunu yapmazsan her cihaz aynı veriyi baştan sona tekrar tekrar okur — hem
# gereksiz ağ yükü hem de etkisiz veri kullanımı.
_pin_memory = torch.cuda.is_available()
train_dl = DataLoader(
    get_dataset("train", num_shards=accelerator.num_processes, shard_index=accelerator.process_index),
    batch_size=4,
    collate_fn=collate_fn,
    num_workers=0,
    pin_memory=_pin_memory,
)
val_dl = DataLoader(
    get_dataset("validation", num_shards=accelerator.num_processes, shard_index=accelerator.process_index),
    batch_size=4,
    collate_fn=collate_fn,
    num_workers=0,
    pin_memory=_pin_memory,
)

optimizer, train_dl, val_dl = accelerator.prepare(optimizer, train_dl, val_dl)

# --- Resume logic ---
# ÖNEMLİ (ücretsiz/preemptible TRC ortamı için): VM/RAM her an geri
# alınabilir. Eğer bu olduğunda yerel disk de sıfırlanırsa (ücretsiz disk
# kalıcı olmayabilir), checkpoints/ klasörü BOŞ görünür ve script hiçbir
# uyarı vermeden SIFIRDAN başlar — HF'ye yüklediğimiz onlarca saatlik
# ilerleme sessizce çöpe gider. Bunu önlemek için: yerelde checkpoint
# yoksa, önce HF Hub'daki (Gokturk97/AlaryQ1CodeQdata) en son checkpoint'i
# indirmeyi dener, o da yoksa ancak o zaman sıfırdan başlar.
last_ckpt = None
ckpt_list = sorted(
    [os.path.join(output_dir, d) for d in os.listdir(output_dir) if "checkpoint-" in d],
    key=lambda p: int(p.split("checkpoint-")[-1]),
)

if ckpt_list:
    last_ckpt = ckpt_list[-1]
    print(f"Yerel checkpoint bulundu: {last_ckpt}")
else:
    print("⚠️  Yerelde checkpoint yok — HF Hub'da yedek var mı kontrol ediliyor "
          "(VM sıfırlanmış/yeniden başlatılmış olabilir)...")
    try:
        from huggingface_hub import list_repo_files, snapshot_download
        repo_files = list_repo_files(CHECKPOINT_HF_REPO, repo_type="dataset")
        remote_steps = sorted({
            int(f.split("/")[1].split("-")[-1])
            for f in repo_files
            if f.startswith("checkpoints/checkpoint-")
        })
        if remote_steps:
            latest_step = remote_steps[-1]
            print(f"☁️  HF Hub'da checkpoint-{latest_step} bulundu, indiriliyor...")
            downloaded_path = snapshot_download(
                repo_id=CHECKPOINT_HF_REPO,
                repo_type="dataset",
                allow_patterns=[f"checkpoints/checkpoint-{latest_step}/*"],
                local_dir="/dev/shm/alary_hf_download",  # diske değil RAM'e indir
            )
            last_ckpt = os.path.join(downloaded_path, "checkpoints", f"checkpoint-{latest_step}")
            print(f"✅ HF Hub'dan indirildi: {last_ckpt}")
        else:
            print("HF Hub'da da checkpoint bulunamadı — gerçekten ilk çalıştırma, sıfırdan başlanıyor.")
    except Exception as e:
        print(f"⚠️  HF Hub'dan checkpoint kontrolü başarısız oldu ({e}) — sıfırdan başlanıyor. "
              "Bu, aslında devam eden bir eğitimi yanlışlıkla sıfırlıyor olabilir, dikkat!")

if last_ckpt:
    accelerator.load_state(last_ckpt)
    print(f"Resumed from {last_ckpt}")
else:
    print("🆕 Hiçbir checkpoint bulunamadı, eğitim sıfırdan başlıyor.")

def evaluate():
    model.eval()
    total_loss = 0
    batch_count = 0
    with torch.no_grad():
        for batch in val_dl:
            outputs = model(input_ids=batch["input_ids"], attention_mask=batch["attention_mask"], labels=batch["labels"])
            total_loss += outputs.loss.item()
            batch_count += 1
    avg_loss = total_loss / batch_count if batch_count > 0 else 0
    print(f"Validation Loss: {avg_loss}")
    model.train()

def diagnose_training_error(loss_value, step_tokens_value, step):
    """
    Loss veya batch'te bir anormallik tespit edildiğinde, olası nedeni
    açıklayan bir mesaj döndürür. Sessizce "NaN loss" yazıp durmak yerine,
    hangi ihtimalin daha olası olduğunu sıralayarak teşhisi kolaylaştırır.
    """
    reasons = []

    if step_tokens_value == 0:
        reasons.append(
            "Bu adımdaki batch'in TÜM örnekleri boş/pad metin içeriyor "
            "(attention_mask.sum() == 0). Olası nedenler:\n"
            "  - dataset.py'deki bir kaynağın 'text' alanı boş geliyor "
            "(ör. Aya'da yaşadığımız 'inputs/targets' alan adı uyuşmazlığı "
            "gibi, farklı bir kaynakta benzer bir şema hatası olabilir)\n"
            "  - tokenizer, bu dildeki/formattaki metni tanımıyor olabilir\n"
            "  - HF Hub'dan çekilen bir shard bozuk/eksik olabilir"
        )

    if loss_value is not None:
        import math
        if math.isnan(loss_value):
            reasons.append(
                "Loss NaN. En sık nedenler:\n"
                "  - Öğrenme oranı (lr) çok yüksek, gradyanlar patlamış olabilir\n"
                "  - Girdi verisinde NaN/Inf değer var (ör. bozuk tokenizasyon)\n"
                "  - bf16/fp16 karışık hassasiyette sayısal taşma (overflow)\n"
                "  - Loss hesaplamasında sıfıra bölme (ör. tüm etiketler -100 "
                "ise, yani tüm batch pad — yukarıdaki 'boş batch' durumuyla "
                "aynı kök nedene işaret edebilir)"
            )
        elif math.isinf(loss_value):
            reasons.append(
                "Loss Inf. Genelde gradyan patlaması (öğrenme oranını düşürmeyi "
                "veya gradient clipping eklemeyi dene) ya da aşırı uzun/tekrarlı "
                "bir sekansın loss'u anormal şişirmesinden kaynaklanır."
            )
        elif loss_value > 20:
            reasons.append(
                f"Loss anormal yüksek ({loss_value:.2f}). Model henüz çok erken "
                "adımdaysa normal olabilir, ama eğitimin ortasında görülüyorsa "
                "kötü bir veri batch'i (ör. bozuk encoding, yanlış dilde/"
                "formatta içerik) veya learning rate spike'ı işareti olabilir."
            )

    if not reasons:
        return None
    return f"\n⚠️  ADIM {step}'DE ANORMALLİK TESPİT EDİLDİ:\n" + "\n".join(reasons)


model.train()
for step, batch in enumerate(train_dl):
    with accelerator.accumulate(model):
        outputs = model(input_ids=batch["input_ids"], attention_mask=batch["attention_mask"], labels=batch["labels"])
        accelerator.backward(outputs.loss)
        optimizer.step()
        optimizer.zero_grad()

    # attention_mask.sum() = pad hariç gerçek token sayısı. Tüm TPU
    # çekirdeklerindeki sayıyı topluyoruz (accelerator.reduce) çünkü her
    # çekirdek farklı bir shard'ı işliyor — sadece bu process'in sayısını
    # tutarsak toplam token bütçesini ~num_processes kat hafife almış oluruz.
    step_tokens = batch["attention_mask"].sum()
    step_tokens = accelerator.reduce(step_tokens, reduction="sum")
    tokens_seen += step_tokens.item()

    # --- Hata teşhisi: her adımda ucuz bir kontrol, sorunu erken yakala ---
    diagnosis = diagnose_training_error(
        loss_value=outputs.loss.item(),
        step_tokens_value=step_tokens.item(),
        step=step,
    )
    if diagnosis and accelerator.is_main_process:
        print(diagnosis)
        import math
        if math.isnan(outputs.loss.item()) or math.isinf(outputs.loss.item()):
            # NaN/Inf loss ile bozuk bir checkpoint kaydetmek yerine,
            # SON İYİ checkpoint'ten devam edilebilmesi için burada duruyoruz.
            print("🛑 NaN/Inf loss nedeniyle eğitim güvenlik amacıyla durduruldu. "
                  "Yukarıdaki teşhisi inceleyip son checkpoint'ten devam et.")
            break

    if step > 0 and step % 1000 == 0:
        save_checkpoint_with_rotation(accelerator, output_dir, step)
        evaluate()

    if step % 100 == 0 and accelerator.is_main_process:
        print(f"Step: {step}, Loss: {outputs.loss.item()}, Tokens: {tokens_seen:,} / {TARGET_TOKENS:,}")

    if tokens_seen >= TARGET_TOKENS:
        if accelerator.is_main_process:
            print(f"✅ Hedef token sayısına ulaşıldı ({tokens_seen:,}), eğitim durduruluyor.")
        break

accelerator.wait_for_everyone()
if accelerator.is_main_process:
    accelerator.unwrap_model(model).save_pretrained("Alary25B_Final")
    print("✅ Model eğitimi tamamlandı!")
