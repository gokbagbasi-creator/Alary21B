import os
import itertools
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from accelerate import Accelerator
from accelerate.utils import set_seed
from diffusers import AutoencoderKL, DDPMScheduler

from model_picasso_dit import build_dit
from model_picasso_text_encoder import CaptionTextEncoder
from dataset_picasso import make_dataset, collate_fn

# ============================================================================
# DONANIM NOTU: TPU v5e-8 için mixed_precision="bf16", T4x2 (plan B) için
# "fp16" kullan — T4 bf16'yı native desteklemiyor. notebook_launcher ile:
#
#   from accelerate import notebook_launcher
#   notebook_launcher(main, args=(), num_processes=8)   # TPU v5e-8
#   notebook_launcher(main, args=(), num_processes=2)   # T4x2 (plan B)
#
# Model küçük (~103M toplam) olduğu için FSDP'ye gerek yok, düz veri
# paralelliği yeterli.
# ============================================================================

OUTPUT_DIR = "checkpoints_picasso"
FINAL_DIR = "Alary_Picasso_mini_Final"
BATCH_SIZE = 32
NUM_TRAIN_TIMESTEPS = 1000
LOG_EVERY = 50
CKPT_EVERY = 1000


def main():
    set_seed(42)
    accelerator = Accelerator(mixed_precision="bf16")
    os.makedirs(OUTPUT_DIR, exist_ok=True)

    # --- Dondurulmuş VAE (eğitilmiyor) ---
    vae = AutoencoderKL.from_pretrained("stabilityai/sd-vae-ft-mse")
    vae.requires_grad_(False)
    vae.eval()

    # --- Eğitilecek modeller: DiT + caption text encoder (ikisi de sıfırdan) ---
    dit = build_dit()
    text_encoder = CaptionTextEncoder()

    noise_scheduler = DDPMScheduler(num_train_timesteps=NUM_TRAIN_TIMESTEPS)

    optimizer = torch.optim.AdamW(
        itertools.chain(dit.parameters(), text_encoder.parameters()),
        lr=1e-4,
    )

    train_ds = make_dataset(num_shards=accelerator.num_processes, shard_index=accelerator.process_index)
    train_dl = DataLoader(train_ds, batch_size=BATCH_SIZE, collate_fn=collate_fn, num_workers=0)

    vae, dit, text_encoder, optimizer, train_dl = accelerator.prepare(
        vae, dit, text_encoder, optimizer, train_dl
    )

    dit.train()
    text_encoder.train()

    for step, batch in enumerate(train_dl):
        with accelerator.accumulate(dit, text_encoder):
            # 1) Görselleri VAE ile latent'e çevir (gradyansız — VAE donuk)
            with torch.no_grad():
                latents = vae.encode(batch["pixel_values"]).latent_dist.sample()
                latents = latents * vae.config.scaling_factor

            # 2) Rastgele gürültü + zaman adımı ekle (standart DDPM eğitim hedefi)
            noise = torch.randn_like(latents)
            timesteps = torch.randint(0, NUM_TRAIN_TIMESTEPS, (latents.shape[0],), device=latents.device).long()
            noisy_latents = noise_scheduler.add_noise(latents, noise, timesteps)

            # 3) Caption'ı encode et
            encoder_hidden_states = text_encoder(batch["input_ids"], batch["attention_mask"])

            # 4) DiT ile gürültüyü tahmin et
            model_output = dit(
                noisy_latents,
                encoder_hidden_states=encoder_hidden_states,
                timestep=timesteps,
                added_cond_kwargs={"resolution": None, "aspect_ratio": None},
            ).sample

            # out_channels = 2*in_channels (learn_sigma=True) -> kanal ekseninde ikiye böl.
            # Basitleştirilmiş L_simple hedefi: sadece gürültü tahminini superviz ediyoruz,
            # varyans dalını değil (improved-diffusion'daki tam hibrit loss değil — daha
            # basit ama daha az veri/adımda da makul sonuç verir).
            noise_pred, _ = model_output.chunk(2, dim=1)

            loss = F.mse_loss(noise_pred, noise)
            accelerator.backward(loss)
            optimizer.step()
            optimizer.zero_grad()

        if step % LOG_EVERY == 0 and accelerator.is_main_process:
            print(f"Step: {step}, Loss: {loss.item():.4f}")

        if step > 0 and step % CKPT_EVERY == 0:
            accelerator.save_state(os.path.join(OUTPUT_DIR, f"checkpoint-{step}"))

    accelerator.wait_for_everyone()
    if accelerator.is_main_process:
        unwrapped_dit = accelerator.unwrap_model(dit)
        unwrapped_text_encoder = accelerator.unwrap_model(text_encoder)

        os.makedirs(FINAL_DIR, exist_ok=True)
        unwrapped_dit.save_pretrained(os.path.join(FINAL_DIR, "dit"))
        torch.save(unwrapped_text_encoder.state_dict(), os.path.join(FINAL_DIR, "text_encoder.pt"))

        # Tokenizer'ı da aynı klasöre kopyala ki hf_loader tek seferde her şeyi yüklesin
        import shutil
        shutil.copy("caption_tokenizer.json", os.path.join(FINAL_DIR, "caption_tokenizer.json"))

        print("✅ Alary Picasso Mini eğitimi tamamlandı!")


if __name__ == "__main__":
    main()
