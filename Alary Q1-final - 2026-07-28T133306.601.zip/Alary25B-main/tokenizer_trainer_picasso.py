import webdataset as wds
from tokenizers import Tokenizer
from tokenizers.models import BPE
from tokenizers.trainers import BpeTrainer

# Not: LLM projesindeki tokenizer.json'dan (128K vocab) FARKLI ve ayrı bir
# tokenizer bu — caption'lar kısa olduğu için çok daha küçük bir vocab yeterli.

TAR_PATTERN = "laion_shards/{00000..NNNNN}.tar"  # kendi shard path'ine göre değiştir
VOCAB_SIZE = 32000

tokenizer = Tokenizer(BPE())
trainer = BpeTrainer(
    vocab_size=VOCAB_SIZE,
    special_tokens=["<pad>", "<bos>", "<eos>", "<unk>"],
)

def caption_iterator():
    ds = wds.WebDataset(TAR_PATTERN, shardshuffle=False).decode().to_tuple("txt")
    for (caption,) in ds:
        yield caption.strip()

print("Caption tokenizer eğitiliyor...")
tokenizer.train_from_iterator(caption_iterator(), trainer=trainer)
tokenizer.save("caption_tokenizer.json")
print("✅ caption_tokenizer.json kaydedildi!")
