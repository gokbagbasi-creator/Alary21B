from transformers import LlamaConfig, LlamaForCausalLM

# İlk deneme koşusu: v5e-8 TPU pod'unda ~150B token ile eğitilecek küçük
# model. 25B'lik ana modelden (model.py) ayrı tutuluyor ki pipeline'ı
# ucuza test edip sonra büyük modele geçebilesin.
config = LlamaConfig(
    hidden_size=3072,
    intermediate_size=8192,
    num_hidden_layers=42,
    num_attention_heads=24,
    num_key_value_heads=8,
    vocab_size=128000,
    # Not: 128K yerine 8192 seçildi. 128K context ile sıfırdan eğitim
    # attention maliyetinin uzunlukla karesel büyümesi yüzünden bu ölçekte
    # bile çok pahalı; önce kısa context ile eğitip sonra "context
    # extension" (RoPE scaling) ile uzatmak çok daha ucuz. 128K istiyorsan
    # bu satırı 128000 yap.
    max_position_embeddings=8192,
    attention_bias=False,
    bos_token_id=1,
    eos_token_id=2,
    rope_theta=10000.0,
)

model = LlamaForCausalLM(config)

total_params = model.num_parameters()
print(f"Model parametreleri: {total_params:,} ({total_params/1e9:.2f}B)")
print(f"Config kaydediliyor...")

model.save_pretrained("Alary5B")
config.save_pretrained("Alary5B")

print("✅ Alary5B modeli başarıyla kaydedildi!")
