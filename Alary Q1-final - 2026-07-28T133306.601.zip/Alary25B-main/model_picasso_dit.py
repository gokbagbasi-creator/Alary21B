from diffusers import PixArtTransformer2DModel

# 74M parametrelik DiT config'i (doğrulanmış — çalıştırınca bu sayıyı verdi).
config = {
    "sample_size": 16,          # 128px görsel / 8x VAE downsample
    "patch_size": 2,            # -> 8x8 = 64 token
    "in_channels": 4,
    "out_channels": 8,          # learn_sigma=True -> 2x in_channels
    "num_layers": 17,
    "num_attention_heads": 8,
    "attention_head_dim": 64,   # 8*64 = 512 hidden_size
    "cross_attention_dim": 512,     # CaptionTextEncoder çıktısıyla eşleşiyor
    "caption_channels": 512,        # aynı şekilde
    "activation_fn": "gelu-approximate",
    "norm_type": "ada_norm_single",
    "num_embeds_ada_norm": 1000,
}

def build_dit():
    return PixArtTransformer2DModel(**config)

if __name__ == "__main__":
    model = build_dit()
    total_params = sum(p.numel() for p in model.parameters())
    print(f"DiT parametreleri: {total_params:,} ({total_params/1e6:.1f}M)")
    model.save_pretrained("Alary_Picasso_mini")
    print("✅ Alary_Picasso_mini (DiT) kaydedildi!")
