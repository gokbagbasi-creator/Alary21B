"""
Hedefli CommonCrawl temizleme — TÜMÜNÜ DEĞİL, sadece:
  1) Türkçe (dil filtresi ile)
  2) FineWeb-2'nin işlemediği YENİ CC dump'ları (Nisan 2024 sonrası)

Neden bu kadarla sınırlı: CulturaX + FineWeb-2 zaten CommonCrawl'ın büyük
kısmını (2024 ortasına kadar) işleyip temizlemiş durumda. Aynı dump'ları
yeniden işlemek büyük ölçüde AYNI içeriği bulur (marjinal kazanç düşük).
Gerçek katkı, onların HENÜZ işlemediği yeni dump'larda.

Kullanılan kütüphane: HuggingFace'in kendi `datatrove` kütüphanesi —
FineWeb/FineWeb-2'nin bizzat inşa edildiği araç, sıfırdan yazmak yerine
bunu kullanmak hem daha güvenilir hem de kanıtlanmış bir pipeline.

Kurulum:
    pip install datatrove[all]
"""

from datatrove.executor.local import LocalPipelineExecutor
from datatrove.pipeline.readers import WarcReader
from datatrove.pipeline.extractors import Trafilatura
from datatrove.pipeline.filters import (
    URLFilter,
    LanguageFilter,
    GopherQualityFilter,
    GopherRepetitionFilter,
)
from datatrove.pipeline.dedup import MinhashDedupSignature, MinhashDedupBuckets, MinhashDedupCluster, MinhashDedupFilter
from datatrove.pipeline.dedup.minhash import MinhashConfig
from datatrove.pipeline.writers.jsonl import JsonlWriter

# FineWeb-2, Nisan 2024'e kadarki dump'ları işledi. Bunun SONRASINDAKİ
# dump'ları hedefliyoruz — gerçekten yeni/örtüşmeyen veri.
# Güncel dump listesi: https://commoncrawl.org/get-started (CC-MAIN-YYYY-WW formatında)
NEW_DUMPS = [
    "CC-MAIN-2024-18",  # Nisan 2024 (FineWeb-2'nin bıraktığı yerden devam)
    "CC-MAIN-2024-22",
    "CC-MAIN-2024-26",
    # ... buraya daha yeni dump'ları ekleyebilirsin, tam liste için:
    # https://data.commoncrawl.org/crawl-data/index.html
]

TARGET_LANGUAGE = "tr"  # sadece Türkçe — "sana dediğim şekilde", tümü değil
OUTPUT_BASE = "cleaned_turkish_cc"  # yerel çıktı klasörü (S3 yerine, Kaggle/lokal için)

minhash_config = MinhashConfig(num_buckets=14, hashes_per_bucket=8)


def build_pipeline_for_dump(dump: str):
    """Tek bir CC dump'ı için: indir -> metni çıkar -> filtrele -> dil filtrele -> kalite filtrele"""
    return [
        WarcReader(
            f"s3://commoncrawl/crawl-data/{dump}/segments/",
            glob_pattern="*/warc/*",
            default_metadata={"dump": dump},
        ),
        URLFilter(),  # zararlı/spam URL'leri baştan ele
        Trafilatura(favour_precision=True),  # HTML -> temiz metin
        LanguageFilter(languages=[TARGET_LANGUAGE]),  # SADECE Türkçe
        GopherRepetitionFilter(),  # aşırı tekrarlı/spam içerik
        GopherQualityFilter(),  # DeepMind Gopher makalesindeki kalite kuralları
        JsonlWriter(f"{OUTPUT_BASE}/{dump}/extracted"),
    ]


def run_extraction():
    """1. Aşama: her dump'ı ayrı ayrı işle (dil + kalite filtresinden geçir)."""
    for dump in NEW_DUMPS:
        executor = LocalPipelineExecutor(
            pipeline=build_pipeline_for_dump(dump),
            tasks=8,  # Kaggle'ın CPU çekirdek sayısına göre ayarla
            logging_dir=f"{OUTPUT_BASE}/{dump}/logs",
        )
        executor.run()
        print(f"✅ {dump} işlendi -> {OUTPUT_BASE}/{dump}/extracted")


def run_deduplication():
    """
    2. Aşama: TÜM dump'lardan çıkan Türkçe metni birlikte MinHash ile
    deduplicate et (hem dump'lar arası hem dump içi tekrarları temizler).
    3 alt-aşamalı bir süreç: signature -> bucket eşleştirme -> filtreleme.
    """
    from datatrove.pipeline.readers import JsonlReader

    all_extracted_dirs = [f"{OUTPUT_BASE}/{dump}/extracted" for dump in NEW_DUMPS]

    # 2a) Her doküman için MinHash imzası çıkar
    for input_dir in all_extracted_dirs:
        sig_executor = LocalPipelineExecutor(
            pipeline=[
                JsonlReader(input_dir),
                MinhashDedupSignature(output_folder=f"{OUTPUT_BASE}/dedup/signatures", config=minhash_config),
            ],
            tasks=8,
        )
        sig_executor.run()

    # 2b) İmzaları bucket'lara göre eşleştirip potansiyel tekrarları bul
    bucket_executor = LocalPipelineExecutor(
        pipeline=[
            MinhashDedupBuckets(
                input_folder=f"{OUTPUT_BASE}/dedup/signatures",
                output_folder=f"{OUTPUT_BASE}/dedup/buckets",
                config=minhash_config,
            ),
        ],
        tasks=minhash_config.num_buckets,
    )
    bucket_executor.run()

    # 2c) Bucket'lardan gerçek tekrar kümelerini oluştur
    cluster_executor = LocalPipelineExecutor(
        pipeline=[
            MinhashDedupCluster(
                input_folder=f"{OUTPUT_BASE}/dedup/buckets",
                output_folder=f"{OUTPUT_BASE}/dedup/clusters",
                config=minhash_config,
            ),
        ],
        tasks=1,
    )
    cluster_executor.run()

    # 2d) Tekrarları eleyip final temiz veriyi yaz
    for input_dir in all_extracted_dirs:
        filter_executor = LocalPipelineExecutor(
            pipeline=[
                JsonlReader(input_dir),
                MinhashDedupFilter(input_folder=f"{OUTPUT_BASE}/dedup/clusters"),
                JsonlWriter(f"{OUTPUT_BASE}/final_deduped"),
            ],
            tasks=8,
        )
        filter_executor.run()

    print(f"✅ Deduplication tamamlandı -> {OUTPUT_BASE}/final_deduped")


if __name__ == "__main__":
    run_extraction()
    run_deduplication()
    print("✅ Hedefli Türkçe CC temizliği tamamlandı. Sonucu HF Hub'a yüklemek için "
          "hf_loader.py'ye benzer bir upload_folder çağrısı ekleyebilirsin.")
